import { test, expect, type Page, type TestInfo } from '@playwright/test';

test.use({
    storageState: './user-session.json',
      screenshot: 'on',
    video: 'on',
    trace: 'on',
});

async function verifyDashboard(page: Page, testInfo: TestInfo): Promise<void> {
    await page.goto('https://app.wingify.com/#/dashboard?accountId=1281703');
    await expect(page).toHaveURL(/dashboard/);

    const screenshotPath = testInfo.outputPath('dashboard.png');
    await page.screenshot({ path: screenshotPath, fullPage: true });
    await testInfo.attach('dashboard-screenshot', {
        path: screenshotPath,
        contentType: 'image/png',
    });

    console.log('Dashboard loaded with screenshot, video, and trace enabled');
    await page.waitForTimeout(3000);
}

test('dashboard media - Test1', async ({ page }, testInfo) => {
    await verifyDashboard(page, testInfo);
});

test('dashboard media - Test2', async ({ page }, testInfo) => {
    await verifyDashboard(page, testInfo);
});

test('dashboard media - Test3', async ({ page }, testInfo) => {
    await verifyDashboard(page, testInfo);
});
